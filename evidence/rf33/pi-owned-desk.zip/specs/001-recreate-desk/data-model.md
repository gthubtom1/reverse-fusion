# Data model

清单: {version:1,next:正安全整数,entries:条目数组}，初始next=1和空数组。
条目: {id:正安全整数,name:string,tag:string,quantity:1..99整数}，所有id唯一且小于next。恢复只检查这些，不擅自拒绝空/长名称等原版允许的保存状态。
新增输入先字符串化/去空白，空分类未分类；按名称必填→长度→数量→重复顺序验证。新增分配next再增计数。删除不回收计数；清空重置计数。
视图过滤name+换行+tag的小写文本；name排序使用zh-CN再id升序，其余order按id降序。汇总只计算可见条目。
更改必须不修改输入state，DOM层先持久化再替换state；失败只更新错误区。
source-ref: spec.md FR-002/003/004/005，reference/core.mjs及原版运行。
