# Quickstart validation

交付后双击“标签收纳盒/start.cmd”，安装Python3的Windows中会启动127.0.0.1:8765并打开浏览器。或者进入该目录运行`python serve.py`。Ctrl+C停止。
添加USB线/数码/2和纸张/办公/3，刷新应保留；查询usb只显示USB线和2件；删除后0项；清空取消不变，确认变空。
全量对照由work/current-case/verify-ui.cjs分别接收原版与候选目录、新输出目录，然后compare-ui.mjs比较，无需应用自身依赖它。playwright属于测试环境。
最终测试与摘要见work/current-case/report/delivery.md。新目录运行不称为VM隔离。
