# Implementation Plan: 标签收纳盒完整复刻

**Branch**: `001-recreate-desk` | **Date**: 2026-11-16 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-recreate-desk/spec.md`

## Summary
完整复刻提供的本地网页。独立实现纯状态层与DOM层，复用浏览器内置能力；从原版观察重建相同CSS尺寸、色值与布局，不重新设计。真实Craft负责所有交付源码写入与检查。

## Technical Context
**Language/Version**: JavaScript ES2022 modules, HTML/CSS; Python3标准库启动器。
**Primary Dependencies**: 交付无第三方包；验收用现有Playwright/Chrome、Node24.22.1与REA6.9.0。
**Storage**: localStorage, key rf-owned-desk-v1, version1。
**Testing**: 冻结的19状态浏览器harness，每侧独立HTTP来源；文本/数据/焦点与PNG逐字节比较；核心差分；错误统计变体必须失败；单独交付目录业务测试。
**Target Platform**: 当前Windows/Chrome157；测试locale zh-CN，1100x850和390x850。
**Project Type**: 静态单页应用。
**Performance Goals**: 本材料内每个浏览器操作默认30s上限，每个完整验收进程120s上限；记录实际时间，不外推吞吐量。
**Constraints**: 原版只读；无远端服务；单写者；不import原件；冻结后不修改Spec/研究/检查。
**Scale/Scope**: 一个页面及全部原有功能，7FR/4SC；不新增编辑、云同步。

## Constitution Check
前置与设计后均通过：证据来自原版源码和已保存运行；全目标无删减；候选独立重写；比较器已在候选前固定；交付无构建依赖。454个静态语义unknown保留，只对已观察的有限行为作声明。没有OS隔离环境时明确未验证，不能用新目录冒充沙箱。

## Project Structure
### Documentation (this feature)
```text
specs/001-recreate-desk/
  spec.md plan.md research.md data-model.md quickstart.md tasks.md
  contracts/ui.md checklists/requirements.md
```
### Source Code (repository root)
```text
work/current-case/native/app/    # 实际Craft写入的候选
  index.html core.mjs page.mjs serve.py start.cmd README.md
标签收纳盒/                       # 检查完成后由同一候选打包交付
work/current-case/              # 原证据、交接、租约、比较和恢复
```
**Structure Decision**: 原版同样是极小静态应用。React/Vite或桌面封装增加依赖且改变运行契约；仅浏览器能力即可满足。保留可测试核心导出initial/restore/change/view，不复制原源码。启动包装使用Python标准库，固定127.0.0.1:8765，Ctrl+C停止。

## Phases and validation
Phase0研究已由原源码及38截图/19状态观察支持；Phase1模型/界面合同/运行指南见同目录。
实现一个冻结批次，检查core/page语法和启动器编译。完成原生cleanup和session finish后更新任务。原版/候选各跑固定harness，核对状态和PNG；错误变体检查失败。额外核心输入族覆盖restore各拒绝分支与remove失败。交付拷贝后再次跑浏览器业务，不允许请求原目录。归档真实官方REA候选分析和有限ledger；Windows原生PTY proof不支持，保留unknown。

## Complexity Tracking
无宪法例外。交付启动器是用户可用性包装，与原版业务事实分开。
