# Research

## 静态应用技术选择
Decision: 直接使用HTML/CSS/原生JS模块与localStorage。
Rationale: 原版没有外部依赖，浏览器内置排序、表单和存储即所需契约。无需框架、数据库或下载。
Alternatives considered: React/Vite增加构建运行负担；Electron增加安装与包体，均无实际能力收益。

## 已验证行为
原版reference/core.mjs/page.mjs/index.html已完整阅读；core-observations.json保存核心实跑，original-ui/observation.json保存两宽度19状态，包括删除、确认框、刷新、坏数据与写失败，无pageerror。原始REA输出保留454静态语义unknown，不把它们伪称已全量证明。

## 比较固定
verify-ui.cjs既有SHA256为48e78b80ab4a28886e4684ffe57c83660972d219486194afc8a2ab02dce47298，候选前已存在。无规范化：state对象逐项比较，PNG文件字节比较，浏览器版本必须一致。焦点/存储字段不跳过。原版和候选分别建空浏览器context及HTTP来源。一个统计错误变体必须被同一比较拒绝。

## 交付
静态源码加标准库HTTP启动器，无需npm install。固定端口保存稳定origin；不同端口/浏览器数据分离。源码与launch包装由真实Craft写入。

## 未验证界限
Windows原生REA PTY进程proof不适用。无额外VM/容器挂载隔离资格，独立新目录测试仅证明包内可运行，不证明原件OS层不可访问。浏览器其他版本/locale、巨大数据和并发跨页冲突未资格化。无影响当前有限功能实现的关键未知。
