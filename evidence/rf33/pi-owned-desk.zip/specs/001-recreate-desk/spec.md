# Feature Specification: 标签收纳盒完整复刻

**Feature Branch**: `001-recreate-desk` (feature identity; no shared repository branch change)

**Created**: 2026-11-16

**Status**: Ready for planning

**Input**: User description: “继续，把这个小软件复刻成界面和功能一样、能直接使用的版本，做好后和原版对比。” Latest: “继续，把还没完成的部分接着做完。”

## User Scenarios & Testing *(mandatory)*

### User Story 1 - 添加与保存物品 (Priority: P1)
用户填写名称、分类和数量，在同一个浏览器来源中保留清单。

**Why this priority**: 构成软件主要用途。

**Independent Test**: 添加合法条目并刷新，名称、分类、数量和顺序保留。

**Acceptance Scenarios**:
1. **Given** 空清单，**When** 添加带两端空格的名称和分类，**Then** 去空格保存，默认最近添加在前，统计正确，清空名称并聚焦；分类和数量保留。
2. **Given** 已有同名同分类，**When** 以英文大小写不同的名称再添加，**Then** 显示原版重名错误，列表和保存状态不变。
3. **Given** 存储写入抛错，**When** 添加，**Then** 显示原异常消息，内存和列表不提交，输入保留。

### User Story 2 - 搜索、排序与统计 (Priority: P1)
用户按名称或分类搜索，在最近添加和名称排序间切换，看到筛选后的数量。

**Why this priority**: 清单的查找与核对功能。

**Independent Test**: 三个条目分别按名称/分类过滤，再切换排序和无匹配查询。

**Acceptance Scenarios**:
1. **Given** 两条不同分类的 USB线，**When** 查询 ` UsB `，**Then** 两条均显示，汇总只统计当前结果。
2. **Given** 多条清单，**When** 按名称排序，**Then** 使用中文名称顺序，同名按添加标识升序。
3. **Given** 有条目，**When** 搜索无匹配，**Then** 显示“没有匹配的条目。”；空清单提示另为“还没有条目，先添加一个吧。”。

### User Story 3 - 删除、清空与恢复 (Priority: P1)
用户删除单条或确认清空全部，并可在刷新后继续使用。

**Why this priority**: 原有数据维护与恢复能力。

**Independent Test**: 删除一项、取消清空、确认清空、刷新；注入损坏保存数据后重载。

**Acceptance Scenarios**:
1. **Given** 多项，**When** 删除第一可见项，**Then** 只删该项并保存，无确认框。
2. **Given** 有数据，**When** 点击清空并取消确认，**Then** 状态不变；确认后清单和标识计数重置。
3. **Given** 保存数据损坏，**When** 载入，**Then** 显示空清单，不在载入时覆盖原始坏数据；下一次成功更改再保存。

### Edge Cases
- 空/全空白名称，32与33 UTF-16单元，数字0/1/99/100/1.5，默认分类，跨分类同名，分类大小写不同。
- 数据读取校验：非1版本、不安全或小于1的next、重复/非法ID、ID不小于next、非字符串名称/分类、非法数量；坏JSON和null均回空状态。
- HTML样式的名称显示为纯文本；错误保留到成功变更或重载，搜索和排序不清错误。
- 原版数量控件保持浏览器原生表单行为；差分直接submit观察核心错误路径，并另测真实按钮和键盘正常提交。
- 不额外修复原版在小屏的输入框溢出；目标是同环境外观一致。

## Requirements *(mandatory)*

### Functional Requirements
- **FR-001**: MUST 保持标题、文案、表单、错误区、搜索/排序、四列表格、两种空态、统计与清空按钮的原版布局、色彩和字形，覆盖1100和390宽度及600断点。
- **FR-002**: MUST 添加名称/分类/数量；去两端空白；空分类为“未分类”；名称必填且最多32 UTF-16单元，数量为1至99整数；同分类名称按en-US忽略大小写防重，保持四条原版验证消息和检查顺序。
- **FR-003**: MUST 搜索名称与分类拼接文本，去查询两端空白且en-US忽略大小写；支持最近ID倒序或zh-CN名称顺序/同名ID升序；统计当前结果条目数和数量总和。
- **FR-004**: MUST 按ID删除且不重排剩余ID；不存在ID报“条目不存在”；清空前确认“确定清空全部条目吗？”，取消无改动，确认恢复初始计数。
- **FR-005**: MUST 在当前浏览器来源保存完整清单；载入校验版本/next/条目类型/唯一ID/数量和ID范围，坏数据回空但不自动写回；成功更改先保存后提交，保存错误显示异常消息且不提交；搜索、排序和输入不持久化。
- **FR-006**: MUST 使用文本呈现条目；添加成功清空名称并聚焦，保留分类/数量；验证失败保留输入和旧数据；每次成功变更清空错误；原版界面不添加新功能。
- **FR-007**: MUST 交付可直接本地启动的独立源码与中文使用说明；不依赖原件、共享工具、外部账号和网络服务；提供固定本地来源、停止和备份/恢复说明。

### Key Entities *(include if feature involves data)*
- **条目**: 正整数标识、名称字符串、分类字符串、1至99的数量。
- **清单**: 版本1、下一个安全整数标识、条目数组。
- **视图**: 临时查询及排序、当前条目和数量总和；不保存。

## Success Criteria *(mandatory)*

### Measurable Outcomes
- **SC-001**: 原版与独立候选在两个指定宽度的19个预先固定状态中，文本、行、错误、焦点、保存数据一致；无页面运行错误。
- **SC-002**: 同环境两个宽度的38张状态截图一致；若失败保留差异并修候选，不能放宽比较规则。
- **SC-003**: 故意将统计数量改错的变体至少一个状态比较失败；有效核心输入族及边界/坏数据对照全部一致。
- **SC-004**: 仅交付文件从单独目录启动后，可以添加、刷新恢复、搜索、删除和清空；原版3个源码摘要保持原值。

## Assumptions
- 单用户、单浏览器来源，不增加云同步、编辑、导入导出、账号或后端。
- 保存依赖浏览器允许本地存储；原版getItem启动失败行为不改善，写失败必须原样显示。
- 验收环境为本机Chrome157、Windows、中文locale；不宣称所有浏览器、无限输入和并发写入等价。
- 文件运行使用本地HTTP；交付启动器是明确 designed 的使用包装，不属于原版业务观察。

## Evidence traceability
全部原版观察均为 observed，FR-007启动包装为用户“能直接使用”的 designed 交付。
原始分析: work/current-case/rea-original.json，ev_c1b69e58cd23f3d0f009173585cb65ab2eabfc648377be62ef3c50b2eadc6338，保留454静态语义unknown。
FR-001: reference/index.html + original-ui全部截图；FR-002/003/004: reference/core.mjs + core-observations.json + original-ui/observation.json；FR-005/006: reference/page.mjs + original-ui/observation.json。
原版UI固定比较器: work/current-case/verify-ui.cjs，19状态/宽度，无规范化容差。

## Clarifications
### Session 2026-11-16
未发现需要用户作决定的关键歧义。全功能与原版外观为既定目标。原分析中未动态验证的删除、确认、持久化和布局已有original-ui观察补证。虚拟机隔离资格与有限浏览器行为比较分开记录。
