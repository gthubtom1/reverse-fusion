# Tasks: 标签收纳盒完整复刻

**Input**: spec.md, plan.md, research.md, data-model.md, contracts/ui.md
**Tests**: 用户要求原版对比；冻结浏览器比较及核心差分为必需验证。源码写入仅native Craft。

## Phase 1: Setup
- [x] T001 固定原版身份、19状态比较器和环境到 work/current-case/notes/validation-commitment.json，映射SC-001/002/003/004。

## Phase 2: Foundational
- [x] T002 创建独立状态与视图核心 work/current-case/native/app/core.mjs：FR-002/003/004/005；名称最多32 UTF-16单元、quantity为1至99整数、id正安全整数唯一且小于next、保留restore接受的字符串内容，引用data-model.md。

## Phase 3: User Story 1 - 添加与保存 (Priority P1)
- [x] T003 [US1] 重建 work/current-case/native/app/index.html 和 page.mjs：FR-001/002/005/006；同环境外观、四条校验错误、先保存后提交、添加焦点与纯文本渲染。

## Phase 4: User Story 2 - 查找与统计 (Priority P1)
- [x] T004 [US2] 在 work/current-case/native/app/page.mjs 接入 FR-003/006 的搜索、排序、可见计数与两空态，保留错误直到成功变更。

## Phase 5: User Story 3 - 数据维护 (Priority P1)
- [x] T005 [US3] 在 work/current-case/native/app/page.mjs 完成 FR-004/005 的删除、清空确认取消与接受、刷新恢复和坏数据恢复。

## Phase 6: Polish & cross-cutting concerns
- [x] T006 创建 work/current-case/native/app/serve.py、start.cmd、README.md：FR-007；静态服务只监听127.0.0.1固定8765，中文启动/停止/备份指南，无原件依赖。
- [x] T007 实际运行 work/current-case/verify-ui.cjs 与 compare-ui.mjs 两侧对照、核心差分和统计错误变体，保存 work/current-case/comparison/：FR-001/002/003/004/005/006，SC-001/002/003。
- [x] T008 打包到 标签收纳盒/，只服务该目录再实跑，检查原件摘要、保存 work/current-case/report/delivery.md 和最终REA记录：FR-007，SC-004。

## Dependencies
T001 → T002 → T003 → T004 → T005；T006可独立编写但同一原生writer串行；T002..T006完成后T007，再T008。
一个冻结native批次选择T002..T006，退出后才勾任务；验证任务由主宿主独立执行。

## Parallel examples
US1中UI样式研究与状态模型审查可独立阅读，实际同文件写入串行；US2/US3均共享page.mjs，不并行写；T006启动说明和核心测试准备可并行读写不同文件，但本批不启第二writer。

## Implementation strategy
先形成完整最小应用，再对照全部19状态及边界。切片不缩减任何FR。失败只修候选，比较器和预期不得放宽。完成原生检查/cleanup/session finish后再更新任务与converge。

## Phase 7: Convergence
- [x] T009 修复 Windows 本地启动器的端口独占绑定，并重跑重复启动失败、正常浏览器操作与退出清理；文件 work/current-case/native-final/app/serve.py，交付“标签收纳盒/serve.py”；per FR-007 / SC-004 / plan: fixed local origin (partial)。失败记录 comparison/launch-process.json 为45秒timeout，Windows Job已清理。其余五文件及业务行为保持前批已比较身份；本阶段新批次继承并重新核对源码摘要。

