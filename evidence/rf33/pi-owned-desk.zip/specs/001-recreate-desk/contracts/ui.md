# UI contract

FR-001/006: 标题、文案、字段与id、表格列、按钮、空态和提示与reference/index.html一致；样式按原版观察尺寸色值实现，保留600px断点及原版小屏布局行为。不加新信息架构。
FR-002: 请填写名称；名称最多32个字符；数量须为1至99的整数；该分类中已有同名条目。
FR-003: 输入事件即时搜索；change事件切换排序；`N 项 · 共 Q 件`。
FR-004: 删除直接提交；清空浏览器confirm“确定清空全部条目吗？”。
FR-005: 保存key=rf-owned-desk-v1；读取错误与原版一致，不改善getItem抛错；写错显示原message。
FR-006: textContent呈现所有数据；添加成功清name并focus，其他输入保留。
FR-007: 入口index.html由127.0.0.1固定端口静态服务；不执行/import reference或共享运行时。
