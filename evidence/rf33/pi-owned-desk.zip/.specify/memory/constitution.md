<!-- Sync Impact: unfilled scaffold -> 1.0.0; five principles adopted; no template modifications; no TODOs. -->
# 标签收纳盒 Constitution

## Core Principles

### I. Evidence before behavior
Existing behavior MUST be supported by the unchanged reference, original REA analysis or actual original runtime observations. Defaults, errors and state transitions MUST NOT be invented. Unknowns MUST return to analysis before affected implementation.

### II. Complete user objective
The delivery MUST recreate the whole supplied local application: appearance, inputs, filtering, sorting, counts, deletion, clear confirmation, persistence and failures. Small batches MUST retain the remaining whole objective. New design requires a recorded user decision.

### III. Independent implementation
Candidate logic MUST be independently authored and MUST NOT import or execute reference files. Original files MUST remain unchanged. Actual native Craft MUST write and check the candidate under a reviewed frozen lease.

### IV. Real comparisons
Validation MUST run both versions, compare states and screenshots at desktop/mobile sizes, exercise invalid inputs and storage failures, and reject a deliberately wrong candidate. Finite comparison MUST NOT be called universal equivalence or native REA process proof.

### V. Simple portable delivery
The delivered application MUST run from its own static directory, without build downloads, account, remote backend or reference checkout. Required launch dependencies and storage origin semantics MUST be documented.

## Scope and constraints
Authority: work/current-case/scope.md and the retained continuation in case.json. Writes belong to this project; network is limited to loopback HTTP for local observation. Shared tool sources, credentials and host configuration remain outside this task. Current Chrome/Node/Windows observations do not establish other browsers or an OS sandbox.

## Development workflow
Execute the generated official Spec workflow, preserve FR/SC/US/task IDs and evidence references, run case-review and semantic handoff, freeze before native Craft writes, finish/cleanup before updating tasks, independently validate, then converge. Keep failures and recovery pointers.

## Governance
Changes MUST record rationale and revalidate affected expectations. Version increments follow semantic versioning: major for incompatible principle changes, minor for new obligations, patch for clarification. Every handoff MUST check these principles. No template placeholders remain.

**Version**: 1.0.0 | **Ratified**: 2026-11-16 | **Last Amended**: 2026-11-16
