import json,hashlib,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];case=root/'work/current-case'
load=lambda p:json.loads((case/p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in load('package-final-identity.json')['files'].items():
 assert sha(root/'标签收纳盒'/name)==digest
 assert sha(case/'native-final/app'/name)==digest
for name,digest in load('notes/validation-commitment.json')['original_sha256'].items():assert sha(root/'reference'/name)==digest
with zipfile.ZipFile(root/'标签收纳盒.zip') as z:
 assert len(z.namelist())==6
 for name,digest in load('package-final-identity.json')['files'].items():assert hashlib.sha256(z.read('标签收纳盒/'+name)).hexdigest()==digest
assert sha(root/'标签收纳盒.zip')==load('archive-identity.json')['sha256']
assert load('case-review-final.json')['status']=='PASS'
assert load('desk-finite-ledger.json')['data']['normalized_result']['status']=='ready'
assert load('desk-full-ledger.json')['data']['normalized_result']['status']=='unknown'
assert load('comparison/package-result.json')['status']=='pass'
assert load('comparison/mutant-result.json')['status']=='fail'
assert load('comparison/launch-result-fixed.json')['status']=='pass'
tasks=(root/'specs/001-recreate-desk/tasks.md').read_text(encoding='utf8')
assert '- [ ]' not in tasks and tasks.count('- [x] T')==9
print(json.dumps({'status':'pass','tasks':9,'archive_files':6,'original_unchanged':True,'case_review':load('case-review-final.json')['summary'],'finite_ledger':'ready','full_static_ledger':'unknown'},ensure_ascii=True))
