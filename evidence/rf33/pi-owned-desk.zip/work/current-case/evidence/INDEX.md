# Evidence index

| id | severity | status | title | file |
|----|----------|--------|-------|------|
- E-001 | info | observed | Original official JavaScript application Evidence | E-001.md
- E-002 | info | observed | Original desktop/mobile runtime observations | E-002.md
- E-003 | info | observed | Original identity and frozen comparison plan | E-003.md
- E-004 | info | observed | Official initial obligation ledger | E-004.md
- E-005 | info | observed | Finite real original candidate comparison and proof | E-005.md
- E-006 | info | observed | Official finite ledger result | E-006.md
- E-007 | info | observed | Final native-bound delivery identity | E-007.md
- E-008 | info | observed | Delivered launcher business and port-failure checks | E-008.md
