import subprocess, json, os, sys
from pathlib import Path
project=Path(__file__).resolve().parents[2]
phase=sys.argv[1]
args={'analyze':['-RequireSpec','-RequireTasks','-IncludeTasks'],'implement':['-RequireTasks','-IncludeTasks'],'converge':['-RequireSpec','-RequireTasks','-IncludeTasks']}[phase]
command=['pwsh','-NoProfile','-File',str(project/'.specify/scripts/powershell/check-prerequisites.ps1'),'-Json',*args]
run=subprocess.run(command,cwd=project,env={**os.environ,'SPECIFY_INIT_DIR':str(project)},capture_output=True,timeout=30)
(project/f'work/current-case/{phase}-prerequisites.json').write_bytes(run.stdout)
(project/f'work/current-case/{phase}-prerequisites.stderr').write_bytes(run.stderr)
print(run.stdout.decode('utf8',errors='replace'))
sys.exit(run.returncode)
