import shutil,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];case=root/'work/current-case';app=root/'标签收纳盒'
backup=case/'comparison/package-before-launch-fix'
shutil.copytree(app,backup)
cleanup=json.loads((case/'final-native-cleanup.json').read_text(encoding='utf-8-sig'))['data']['output_digests']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for p in (case/'native-final/app').iterdir():
 assert p.is_file() and sha(p)==cleanup['app/'+p.name]
 if p.name!='serve.py':assert sha(p)==sha(backup/p.name)
 shutil.copy2(p,app/p.name);files[p.name]=sha(app/p.name)
report={'status':'packaged','files':files,'changed_since_browser_comparison':['serve.py'],'browser_sources_unchanged':True,'native_lease':'work/current-case/native-final-lease.json','backup':'work/current-case/comparison/package-before-launch-fix'}
(case/'package-final-identity.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(report))
