import json, hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2]
case=root/'work/current-case'
load=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
hashfile=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
original=load(case/'rea-original.json')
records=original['records']
primary=next(r for r in records if r['operation']=='analyze_javascript_application')
sha=primary['subject']['digest']['sha256']
titles=['desktop and mobile layout','validated addition and duplicate detection','filtering ordering and totals','remove and confirmed clear','persistence and storage failure','text rendering and focus','independent usable distribution']
reviewed=[]
for n,title in enumerate(titles,1):
    reviewed.append({'obligation_id':f'desk-fr-{n:03}', 'obligation_version':1,'title':title,'application_layer':'runtime','family':'desk-ui','target':{'semantic_node_id':None,'application_node_id':None,'artifact_sha256':sha,'location':'reference/index.html'},'required':True,'required_case_kinds':['positive','negative','malformed'],'required_original_authority':'runtime','required_fixture_authority':'integration','required_verifier_authority':'integration','requires_parser_type':False,'dependency_obligation_ids':[],'residual_unknown_ids':[],'unavailable_authority':[],'required_next_evidence':['actual independent browser comparison'], 'disposition':'active','review_evidence_ids':[primary['evidence_id']]})
(case/'ledger-initial-input.json').write_text(json.dumps({'evidence_bundle':original,'manifest':{'contradictions':[],'bindings':[]},'reviewed_obligations':reviewed},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(case/'notes').mkdir(exist_ok=True)
commitment={'scope':'all supplied local application behavior, finite Chrome cases','original_sha256':{p.name:hashfile(p) for p in (root/'reference').iterdir() if p.is_file()},'ui_verifier_sha256':hashfile(case/'verify-ui.cjs'),'original_observation_sha256':hashfile(case/'original-ui/observation.json'),'viewports':[1100,390],'height':850,'locale':'zh-CN','comparison':'exact states, screenshots bytes, no field exclusions or tolerance','mutant':'incorrect visible quantity total must fail','reference_execution':'separate loopback root and fresh browser contexts','limits':['finite behavior only','not native PTY proof','new directory is not OS sandbox']}
(case/'notes/validation-commitment.json').write_text(json.dumps(commitment,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'original_records':len(records),'original_evidence_id':primary['evidence_id'],'reviewed_obligations':len(reviewed)}))
