import json
from pathlib import Path
requests=Path(__file__).resolve().parent/'requests'
requests.mkdir(exist_ok=True)
files={
'core':('core.mjs',r'''// Independently authored state layer for the observed local desk behavior.
export const initial = () => ({version: 1, next: 1, entries: []});
const fold = value => value.toLocaleLowerCase('en-US');
export function restore(text) {
  try {
    if (!text) return initial();
    const saved = JSON.parse(text);
    const identifiers = new Set();
    if (saved.version !== 1 || !Number.isSafeInteger(saved.next) || saved.next <= 0 || !Array.isArray(saved.entries)) return initial();
    for (const entry of saved.entries) {
      if (!Number.isSafeInteger(entry.id) || entry.id <= 0 || entry.id >= saved.next || identifiers.has(entry.id)) return initial();
      if (typeof entry.name !== 'string' || typeof entry.tag !== 'string' || !Number.isInteger(entry.quantity) || entry.quantity < 1 || entry.quantity > 99) return initial();
      identifiers.add(entry.id);
    }
    return saved;
  } catch { return initial(); }
}
export function change(state, action) {
  const draft = structuredClone(state);
  switch (action.type) {
    case 'clear': return initial();
    case 'remove': {
      const index = draft.entries.findIndex(entry => entry.id === action.id);
      if (index < 0) throw Error('条目不存在');
      draft.entries.splice(index, 1);
      return draft;
    }
    case 'add': {
      const name = String(action.name ?? '').trim();
      const tag = String(action.tag ?? '').trim() || '未分类';
      const quantity = Number(action.quantity);
      if (name.length === 0) throw Error('请填写名称');
      if (name.length > 32) throw Error('名称最多32个字符');
      if (!(Number.isInteger(quantity) && quantity >= 1 && quantity <= 99)) throw Error('数量须为1至99的整数');
      for (const entry of draft.entries) {
        if (entry.tag === tag && fold(entry.name) === fold(name)) throw Error('该分类中已有同名条目');
      }
      const id = draft.next;
      draft.next += 1;
      draft.entries = [...draft.entries, {id, name, tag, quantity}];
      return draft;
    }
    default: throw Error('未知操作');
  }
}
export function view(state, query = '', order = 'newest') {
  const needle = fold(String(query).trim());
  const entries = [];
  for (const entry of state.entries) {
    if (fold(entry.name + '\n' + entry.tag).includes(needle)) entries.push(entry);
  }
  entries.sort(order === 'name'
    ? (left, right) => left.name.localeCompare(right.name, 'zh-CN') || left.id - right.id
    : (left, right) => right.id - left.id);
  let quantity = 0;
  for (const entry of entries) quantity += entry.quantity;
  return {entries, items: entries.length, quantity};
}
'''),
'page':('page.mjs',r'''import {restore, change, view} from './core.mjs';
const controls = Object.fromEntries(['add','name','tag','quantity','query','order','rows','empty','summary','error','clear'].map(id => [id, document.getElementById(id)]));
const storageKey = 'rf-owned-desk-v1';
let current = restore(localStorage.getItem(storageKey));
function draw() {
  const visible = view(current, controls.query.value, controls.order.value);
  const fragment = document.createDocumentFragment();
  for (const entry of visible.entries) {
    const row = document.createElement('tr');
    for (const text of [entry.name, entry.tag, entry.quantity]) {
      const td = document.createElement('td');
      td.textContent = text;
      row.appendChild(td);
    }
    const actionCell = document.createElement('td');
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'remove';
    remove.textContent = '删除';
    remove.onclick = () => commit({type: 'remove', id: entry.id});
    actionCell.appendChild(remove);
    row.appendChild(actionCell);
    fragment.appendChild(row);
  }
  controls.rows.replaceChildren(fragment);
  controls.empty.hidden = visible.items > 0;
  controls.empty.textContent = current.entries.length === 0 ? '还没有条目，先添加一个吧。' : '没有匹配的条目。';
  controls.summary.textContent = `${visible.items} 项 · 共 ${visible.quantity} 件`;
}
function commit(action) {
  try {
    const updated = change(current, action);
    localStorage.setItem(storageKey, JSON.stringify(updated));
    current = updated;
    controls.error.textContent = '';
    draw();
    return true;
  } catch (failure) {
    controls.error.textContent = failure.message;
    return false;
  }
}
controls.add.onsubmit = event => {
  event.preventDefault();
  const accepted = commit({type: 'add', name: controls.name.value, tag: controls.tag.value, quantity: controls.quantity.value});
  if (accepted) {
    controls.name.value = '';
    controls.name.focus();
  }
};
controls.query.oninput = draw;
controls.order.onchange = draw;
controls.clear.onclick = () => {
  if (window.confirm('确定清空全部条目吗？')) commit({type: 'clear'});
};
draw();
'''),
'index':('index.html',r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>标签收纳盒</title>
<style>
* { box-sizing: border-box; }
body { margin: 0; background: #f4f2ee; color: #282b28; font: 16px/1.5 system-ui,sans-serif; }
main { max-width: 860px; margin: 48px auto; padding: 28px; background: white; border: 1px solid #d7d8d2; border-radius: 8px; }
h1 { margin: 0 0 4px; font-size: 28px; }
p { color: #656961; }
form, .toolbar { display: flex; gap: 12px; flex-wrap: wrap; margin: 24px 0; }
label { display: grid; gap: 5px; flex: 1; }
input, select, button { font: inherit; padding: 9px 12px; border: 1px solid #babeb4; border-radius: 4px; }
button { cursor: pointer; background: #365b45; color: white; align-self: end; }
button.secondary { background: white; color: #365b45; }
#error { min-height: 24px; color: #a33124; }
table { width: 100%; border-collapse: collapse; }
td, th { text-align: left; border-bottom: 1px solid #e5e7df; padding: 12px 8px; }
th { font-weight: 600; color: #565f51; }
#empty { padding: 24px; text-align: center; }
footer { display: flex; justify-content: space-between; margin-top: 20px; }
.remove { padding: 4px 9px; background: white; color: #8b3b32; }
@media (max-width: 600px) { main { margin: 12px; padding: 18px; } label { min-width: 120px; } }
</style>
</head>
<body>
<main>
<h1>标签收纳盒</h1><p>把零散物品放进分类，数量与清单只保存在当前浏览器。</p>
<form id="add"><label>名称<input id="name" autocomplete="off"></label><label>分类<input id="tag" autocomplete="off"></label><label>数量<input id="quantity" type="number" value="1"></label><button>添加条目</button></form>
<div id="error" role="alert"></div>
<div class="toolbar"><label>搜索名称或分类<input id="query" placeholder="输入关键词"></label><label>排序<select id="order"><option value="newest">最近添加</option><option value="name">按名称</option></select></label></div>
<table><thead><tr><th>名称</th><th>分类</th><th>数量</th><th>操作</th></tr></thead><tbody id="rows"></tbody></table>
<div id="empty">还没有条目，先添加一个吧。</div>
<footer><span id="summary"></span><button type="button" id="clear" class="secondary">清空全部</button></footer>
</main>
<script type="module" src="./page.mjs"></script>
</body>
</html>
'''),
'serve':('serve.py',r'''"""Start the delivered local application. No third-party dependencies."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import socket
import threading
import webbrowser

class LocalServer(ThreadingHTTPServer):
    allow_reuse_address = not hasattr(socket, 'SO_EXCLUSIVEADDRUSE')

    def server_bind(self):
        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

def main():
    parser = argparse.ArgumentParser(description="Local desk application server")
    parser.add_argument('--no-open', action='store_true', help='Do not open a browser automatically')
    args = parser.parse_args()
    directory = Path(__file__).resolve().parent
    url = 'http://127.0.0.1:8765/'
    handler = partial(SimpleHTTPRequestHandler, directory=str(directory))
    try:
        server = LocalServer(('127.0.0.1', 8765), handler)
    except OSError as error:
        print('Cannot start local server: ' + str(error))
        print('Port 8765 may already be in use. Close the previous application and retry.')
        return 1
    print('Open ' + url + ' (Ctrl+C to stop)', flush=True)
    opener = None
    if not args.no_open:
        opener = threading.Timer(0.4, webbrowser.open, args=(url,))
        opener.daemon = True
        opener.start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if opener:
            opener.cancel()
        server.server_close()
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
'''),
'start':('start.cmd','''@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nwhere py >nul 2>nul\r\nif errorlevel 1 (\r\n  python serve.py\r\n) else (\r\n  py -3 serve.py\r\n)\r\nif errorlevel 1 pause\r\nendlocal\r\n'''),
'readme':('README.md',r'''# 标签收纳盒

添加、分类、搜索和统计零散物品的小工具。数据只保存在当前浏览器，无账号，无云同步。

## 使用

Windows安装Python3后双击`start.cmd`，浏览器会打开`http://127.0.0.1:8765/`。也可在此目录运行`python serve.py`。如不希望自动打开浏览器，运行`python serve.py --no-open`，再手动打开该网址。保持命令窗口打开，结束时按Ctrl+C。

填写名称、分类、数量后点击“添加条目”；分类可留空，数量为1至99的整数。搜索名称或分类，可按最近添加或名称排序；统计只计算筛选结果。删除单条无需确认，清空全部会要求确认。

刷新或关闭后再用同一网址和浏览器打开，会保留清单。浏览器、用户配置、主机名或端口不同，数据互相独立。清除网站数据、使用隐私模式可能丢失清单。此程序不会上传清单。

## 备份与恢复

重要数据可在浏览器开发者工具的Application/应用→Local Storage中找到此网址下的`rf-owned-desk-v1`，将完整值保存为自己的备份文本；恢复时把同一键的值替换为备份，再刷新。请先另存当前值。损坏或不合法数据会显示空清单；下一次成功添加会覆盖坏数据。没有内置导入导出界面。

## 运行说明

只需本目录六个文件和Python3，应用不依赖原版reference、Reverse Fusion、Node或npm包。仅监听本机127.0.0.1，启动器使用固定8765端口，方便保持保存来源不变。端口被占用时关闭之前启动的窗口后重试，不会自动选择新端口。

本版本按提供的原版界面和行为独立编写。测试覆盖当前Chrome桌面和手机尺寸；详细原版对照和范围见项目的work/current-case/report/delivery.md。不存在云备份或其他浏览器兼容性保证。
''')}
for name,(filename,content) in files.items():
    (requests/(name+'.json')).write_text(json.dumps({'path':'app/'+filename,'content':content},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('Authored six native write requests; candidate files will be written by actual Craft engine.')
