import json,sys
from pathlib import Path
from reverse_fusion.owned_process import run_owned
root=Path(__file__).resolve().parents[2]
case=root/'work/current-case'
result=run_owned(['D:/Project/reverse/vendor/node/node-v24.22.1-win-x64/node.exe',str(case/'verify-launch.cjs'),sys.executable,str(root/'标签收纳盒'),str(case/'comparison/launch-result-fixed.json')],cwd=root,stdin=b'',timeout=45,memory_mb=2048)
for key in ['stdout','stderr']:result[key]=result[key].decode('utf8',errors='replace')
(case/'comparison/launch-process-fixed.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,ensure_ascii=True))
raise SystemExit(0 if result['status']=='observed' and result['exit_code']==0 else 1)
