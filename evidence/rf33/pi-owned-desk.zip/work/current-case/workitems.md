# Work Items

| ID | title | role | targets | surface | status | evidence | notes |
|----|-------|------|---------|---------|--------|----------|-------|
| WI-001 | Restore scope and original objective | lead | current-case | process | done | E-003 | User now requests complete recreation |
| WI-002 | Original static/runtime behavior | lead | reference | JS/browser | done | E-001,E-002 | Original unknowns retained |
| WI-003 | Official Spec workflow and semantic handoff | lead | specs/001-recreate-desk | process | done | E-004 | Actual templates/scripts, all FR mapped |
| WI-004 | Native independent implementation | lead/native Craft | native-final/app | local source | done | E-007 | Final full task lease finished |
| WI-005 | Differential tests, wrong variant, package and report | lead | candidate/reference | runtime | done | E-005,E-006,E-008 | T007/T008/T009 verified |

## Coverage
- [x] Recon/analysis complete for selected local behavior
- [x] Critical/High candidates triaged: no security findings asserted
- [x] Evidence with raw artifact hashes retained
- [x] Callflow documented in final report
- [x] Timeline continued in same case
- [x] Report and anonymized local experience

## Refs
scope.md, timeline.md, case.json, ../../specs/001-recreate-desk/tasks.md
