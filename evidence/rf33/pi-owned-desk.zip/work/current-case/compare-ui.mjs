import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const [leftPath,rightPath,output]=process.argv.slice(2);
const left=JSON.parse(fs.readFileSync(leftPath,'utf8')),right=JSON.parse(fs.readFileSync(rightPath,'utf8'));
const failures=[];let states=0,pngs=0;
const check=(label,fn)=>{try{fn()}catch(e){failures.push({label,error:e.message})}};
check('browser',()=>assert.equal(right.browser,left.browser));
check('verifier',()=>assert.equal(right.verifierSha256,left.verifierSha256));
check('viewport count',()=>assert.equal(right.runs.length,left.runs.length));
for(const [i,a]of left.runs.entries()){
 const b=right.runs[i];if(!b){failures.push({label:'missing viewport '+a.width});continue;}
 check('viewport '+i,()=>assert.equal(b.width,a.width));
 check('original errors '+a.width,()=>assert.deepEqual(a.errors,[]));
 check('candidate errors '+a.width,()=>assert.deepEqual(b.errors,[]));
 check('state count '+a.width,()=>assert.equal(b.states.length,a.states.length));
 for(const [j,state]of a.states.entries()){check(a.width+' state '+state.name,()=>assert.deepEqual(b.states[j],state));states++;}
 for(const [j,screen]of a.screens.entries()){check(a.width+' png '+screen.name,()=>assert.deepEqual(b.screens[j],screen));pngs++;}
}
const digest=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const result={status:failures.length?'fail':'pass',states,pngs,inputs:{original:{path:leftPath,sha256:digest(leftPath)},candidate:{path:rightPath,sha256:digest(rightPath)}},verifier_sha256:digest(new URL(import.meta.url)),failures};
if(output){if(fs.existsSync(output))throw Error('Do not overwrite results');fs.writeFileSync(output,JSON.stringify(result,null,2));}
console.log(JSON.stringify(result));process.exitCode=failures.length?1:0;
