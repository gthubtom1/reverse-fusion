import json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2]
case='work/current-case'
def load(p):return json.loads((root/p).read_text(encoding='utf-8-sig'))
def ref(p):return {'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()}
ledger=load(case+'/ledger-initial.json')['data']['normalized_result']
indices={o['obligation_id']:i for i,o in enumerate(ledger['obligations'])}
manifest={'manifest_version':1,'case_root':case,'context_refs':{k:ref(f'{case}/{k}.md')for k in ['scope','timeline','workitems']},'feature_refs':{k:ref(f'specs/001-recreate-desk/{k}.md')for k in ['spec','plan','tasks']},'bundle_refs':[ref(case+'/rea-original.json')],'requirements':[]}
for n in range(1,8):
 manifest['requirements'].append({'fr_id':f'FR-{n:03}','source_kind':'designed' if n==7 else 'observed','evidence_refs':[{'evidence_id':eid,'record_ref':ref(f'{case}/evidence/{eid}.md')}for eid in (['E-003'] if n==7 else ['E-001','E-002'])],'obligation_ref':{'document_ref':ref(case+'/ledger-initial.json'),'pointer':f'/data/normalized_result/obligations/{indices[f"desk-fr-{n:03}"]}'},'unknown_refs':[]})
(root/f'{case}/notes/handoff-launch.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps({'reviewed_obligations':list(indices),'status':ledger['status'],'summary':ledger['summary']},ensure_ascii=True))
