# 分析范围与工作项

原始请求：先分析这个文件夹里的小软件，告诉我它有什么功能，暂时不要写复刻版。
目标：reference/ 中的“标签收纳盒”。只读源码、静态分析及无网络、无持久状态的核心函数验证；不修改原版，不创建候选，不进入 Spec/Craft。

## WI-001
- case: work/current-case；primary: R3 / js-reverse；phase: static
- question: 原版 JS 声明了哪些功能、数据约束和浏览器依赖？
- target: reference/core.mjs SHA256 ddf8609a5fbb3e194d3973228da56771c6c3c03329166f0e5a95e29e1e94b9f2；reference/page.mjs SHA256 83f93826a55b128f7c711ebc7052455330896b29d3553c895b1ac39433d92c63
- carry_forward_refs: case.json、此范围记录、reference/README.txt、reference/index.html、reference/core.mjs、reference/page.mjs
- provider: official REA 6.9.0，使用 bridge 返回的真实 argv；工具索引不存在，不依赖其假定资格
- allowed: 本地静态 JS 分析；forbidden: 修改原版、外网、目标持久状态、复刻
- write_scope: work/current-case/ 下的原始分析产物
- budget: 60s total, per-source 15s, worker heap 512MiB, max heavy providers 1
- expected: rea-original.json、rea-summary.json、rea-stderr.txt
- cleanup: 有限同步 CLI；不留服务；超时后清理再替换
- acceptance: 检查实际输出是否包含原始源码分析及局限；不把静态结论当作界面实测

## WI-002
- question: 添加、搜索统计、排序、删除、清空、数据恢复及非法输入的核心函数实际返回什么？
- allowed: 已通读 core.mjs 后，在 Node 中导入原函数，以内存样例调用；无文件写入、无网络、无浏览器数据修改
- budget: 20s；expected: core-observations.json
- cleanup: 同步 Node 退出；不安装依赖、不留进程
