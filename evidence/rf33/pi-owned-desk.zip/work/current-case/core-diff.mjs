import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
const [originalFile,candidateFile,output]=process.argv.slice(2);
const left=await import(pathToFileURL(path.resolve(originalFile)));
const right=await import(pathToFileURL(path.resolve(candidateFile)));
const checks=[];
const result=(fn)=>{try{return {value:fn()}}catch(e){return {error:e.message}}};
function equal(label,call){const a=result(()=>call(left)),b=result(()=>call(right));assert.deepEqual(b,a,label);checks.push({label,original:a,candidate:b});}
equal('initial',m=>m.initial());
const valid={version:1,next:4,entries:[{id:1,name:'USB线',tag:'数码',quantity:2},{id:2,name:'纸张',tag:'办公',quantity:99},{id:3,name:'usb线',tag:'备用',quantity:3}]};
const variants=[null,'','{bad','null','{}','[]',JSON.stringify(valid)];
for(const patch of [{version:2},{next:0},{next:1.5},{next:9007199254740992},{entries:{}},{entries:[...valid.entries,valid.entries[0]]},{next:3}])variants.push(JSON.stringify({...valid,...patch}));
for(const field of ['id','name','tag','quantity'])for(const value of [null,0,-1,1.5,100,{},''])variants.push(JSON.stringify({...valid,entries:[{...valid.entries[0],[field]:value}]}));
variants.push(JSON.stringify({version:1,next:3,entries:[{id:1,name:'',tag:'',quantity:1},{id:2,name:'甲'.repeat(33),tag:'自由',quantity:99}]}));
variants.forEach((v,i)=>equal('restore-'+i,m=>m.restore(v)));
const adds=[{}, {name:'  缆线  ',tag:' ',quantity:'2'}, {name:'USB线',tag:'数码',quantity:1},{name:'usb线',tag:'数码',quantity:1},{name:'USB线',tag:'数码A',quantity:1},{name:'甲'.repeat(32),quantity:1},{name:'甲'.repeat(33),quantity:1},{name:'😀'.repeat(16),quantity:1},{name:'😀'.repeat(17),quantity:1},{name:'<img src=x onerror=alert(1)>',quantity:2}];
for(const name of ['', ' ', '新条目'])for(const quantity of [null,'',0,1,99,100,-1,1.5,'1e1','bad'])adds.push({name,quantity});
for(const [i,item]of adds.entries())equal('add-'+i,m=>{const before=JSON.stringify(valid);const next=m.change(valid,{type:'add',...item});assert.equal(JSON.stringify(valid),before);return next});
for(const id of [1,2,3,4,'1',null])equal('remove-'+String(id),m=>m.change(valid,{type:'remove',id}));
equal('clear',m=>m.change(valid,{type:'clear'}));equal('unknown-action',m=>m.change(valid,{type:'other'}));
for(const query of ['', '  USB ', '办公', '找不到','线\n数码'])for(const order of ['newest','name','other'])equal('view-'+query+'-'+order,m=>m.view(valid,query,order));
equal('name-tie',m=>m.view({version:1,next:3,entries:[{id:2,name:'同名',tag:'B',quantity:1},{id:1,name:'同名',tag:'A',quantity:1}]},'','name'));
const report={status:'pass',count:checks.length,checks};
if(output){if(fs.existsSync(output))throw Error('Do not overwrite previous results');fs.writeFileSync(output,JSON.stringify(report,null,2));}
console.log(JSON.stringify({status:report.status,cases:checks.length}));
