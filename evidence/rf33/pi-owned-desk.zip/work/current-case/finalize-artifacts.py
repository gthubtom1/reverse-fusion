import subprocess,json,zipfile,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];case=root/'work/current-case'
entries=[('E-005','Finite real original candidate comparison and proof','desk-finite-proof.json','node work/current-case/prove-finite.mjs'),('E-006','Official finite ledger result','desk-finite-ledger.json','official REA build-reconstruction-obligation-ledger desk-finite-ledger-input.json'),('E-007','Final native-bound delivery identity','package-final-identity.json','python work/current-case/package-final.py'),('E-008','Delivered launcher business and port-failure checks','comparison/launch-result-fixed.json','python work/current-case/run-launch.py')]
for eid,title,artifact,repro in entries:
 p=subprocess.run(['pwsh','-NoProfile','-File','D:/Project/reverse/skills/scripts/append-evidence.ps1','-CaseRoot',str(case),'-Id',eid,'-Title',title,'-ReproCommand',repro,'-ArtifactPath',artifact,'-Status','observed','-Notes','Finite observed result; full static ledger remains unknown and no OS isolation claimed.'],capture_output=True,cwd=root,timeout=15)
 if p.returncode:raise RuntimeError(p.stderr.decode('utf8',errors='replace'))
 print(p.stdout.decode('utf8',errors='replace'))
archive=root/'标签收纳盒.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted((root/'标签收纳盒').iterdir()):
  assert p.is_file() and not p.is_symlink();z.write(p,'标签收纳盒/'+p.name)
result={'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':6}
(case/'archive-identity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,ensure_ascii=True))
