﻿# Case Scope

## meta
- case_id: current-case
- created: 2026-11-16T10:31:13.3296528+08:00
- operator: local
- project_root: D:\Project\reverse\state\rf33-pi-entry
- primary_skill: js-reverse/SKILL.md
- primary_id: R3
- lead_role: lead
- specialist_roles: []
- hint: JavaScript local desk reconstruction
- preset: none

## auth
- status: granted
- basis: own_system
- evidence_of_auth: User asks to finish same UI/function replica and comparison
- MUST NOT proceed if status != granted

## in_scope
- assets:
  - reference/
  - work/current-case/
  - specs/001-recreate-desk/
  - 标签收纳盒/
  - loopback static HTTP only
- surfaces: [local_browser_ui, javascript_state, localStorage]
- activities: [read_original, analyze, run_local_original, independent_reconstruction, compare, package]

## out_of_scope
- assets: []
- activities: [dos, phishing_real_users, unrestricted_exfil]

## network_profile
- mode: lab_only
- notes: |
    offline | lab_only | authorized_target_only | unrestricted_lab
    Change mode only after auth.status = granted.

## deliverables
- report: true
- field_journal: true
- diagrams: true
- timeline: true

## constraints
- timebox: {}
- stealth: low
- data_handling: anonymize

## signoff
- ready_for_act: true
- checklist:
  - [x] auth.status = granted
  - [x] in_scope.assets non-empty OR offline sample path set
  - [x] network_profile.mode chosen
  - [x] out_of_scope reviewed
  - [x] roles assigned (current host owns analysis, implementation reasoning and validation; native Craft is the single candidate writer)

## ops_refs
- skills/ops/scope-contract.md
- skills/ops/evidence-finding-path.md
- skills/ops/role-map.md
- skills/ops/timeline-workitem.md
- skills/ops/IDENTITY.md