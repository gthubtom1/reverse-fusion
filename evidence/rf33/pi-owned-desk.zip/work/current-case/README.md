﻿# Case current-case

1. Scope is ready_for_act=true (auth granted + in_scope set)
2. Open primary skill: skills/js-reverse/SKILL.md
3. Append `timeline.md`; update `workitems.md`
4. Append Evidence: `skills/scripts/append-evidence.ps1 -CaseRoot <this dir> ...`
5. Promote findings with Evidence chain (skills/ops/evidence-finding-path.md)
6. Report via docs-generator; journal via field-journal