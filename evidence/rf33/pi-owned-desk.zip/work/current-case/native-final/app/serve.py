"""Start the delivered local application. No third-party dependencies."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import socket
import threading
import webbrowser

class LocalServer(ThreadingHTTPServer):
    allow_reuse_address = not hasattr(socket, 'SO_EXCLUSIVEADDRUSE')

    def server_bind(self):
        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

def main():
    parser = argparse.ArgumentParser(description="Local desk application server")
    parser.add_argument('--no-open', action='store_true', help='Do not open a browser automatically')
    args = parser.parse_args()
    directory = Path(__file__).resolve().parent
    url = 'http://127.0.0.1:8765/'
    handler = partial(SimpleHTTPRequestHandler, directory=str(directory))
    try:
        server = LocalServer(('127.0.0.1', 8765), handler)
    except OSError as error:
        print('Cannot start local server: ' + str(error))
        print('Port 8765 may already be in use. Close the previous application and retry.')
        return 1
    print('Open ' + url + ' (Ctrl+C to stop)', flush=True)
    opener = None
    if not args.no_open:
        opener = threading.Timer(0.4, webbrowser.open, args=(url,))
        opener.daemon = True
        opener.start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if opener:
            opener.cancel()
        server.server_close()
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
