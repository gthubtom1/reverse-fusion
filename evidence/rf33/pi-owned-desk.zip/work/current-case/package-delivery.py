import json,hashlib,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[2]
case=root/'work/current-case'
source=case/'native-complete/app'
package=root/'标签收纳盒'
mutant=case/'comparison/wrong-count'
assert not package.exists() and not mutant.exists(), 'Preserve existing output'
cleanup=json.loads((case/'complete-native-cleanup.json').read_text(encoding='utf-8-sig'))['data']['output_digests']
expected=['index.html','core.mjs','page.mjs','serve.py','start.cmd','README.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package.mkdir()
manifest={}
for name in expected:
 p=source/name
 assert p.is_file() and not p.is_symlink()
 assert sha(p)==cleanup['app/'+name]
 assert sha(p)==sha(case/'native/app'/name), 'first UI tests must cover exact bytes'
 shutil.copy2(p,package/name)
 assert sha(p)==sha(package/name)
 manifest[name]=sha(p)
shutil.copytree(package,mutant)
p=mutant/'page.mjs';text=p.read_text(encoding='utf8')
assert text.count('${visible.quantity}')==1
p.write_text(text.replace('${visible.quantity}','${visible.quantity + 1}'),encoding='utf8')
commit=json.loads((case/'notes/validation-commitment.json').read_text(encoding='utf8'))
for name,digest in commit['original_sha256'].items(): assert sha(root/'reference'/name)==digest
report={'status':'packaged','package':'标签收纳盒','files':manifest,'native_lease':'work/current-case/native-complete-lease.json','first_ui_test_bytes_match':True,'original_unchanged':True,'mutant':'comparison/wrong-count changes displayed quantity only','isolation':'new delivery directory; not OS sandbox'}
(case/'package-identity.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':'packaged','files':len(manifest),'original_unchanged':True}))
