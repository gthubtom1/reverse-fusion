// Independently authored state layer for the observed local desk behavior.
export const initial = () => ({version: 1, next: 1, entries: []});
const fold = value => value.toLocaleLowerCase('en-US');
export function restore(text) {
  try {
    if (!text) return initial();
    const saved = JSON.parse(text);
    const identifiers = new Set();
    if (saved.version !== 1 || !Number.isSafeInteger(saved.next) || saved.next <= 0 || !Array.isArray(saved.entries)) return initial();
    for (const entry of saved.entries) {
      if (!Number.isSafeInteger(entry.id) || entry.id <= 0 || entry.id >= saved.next || identifiers.has(entry.id)) return initial();
      if (typeof entry.name !== 'string' || typeof entry.tag !== 'string' || !Number.isInteger(entry.quantity) || entry.quantity < 1 || entry.quantity > 99) return initial();
      identifiers.add(entry.id);
    }
    return saved;
  } catch { return initial(); }
}
export function change(state, action) {
  const draft = structuredClone(state);
  switch (action.type) {
    case 'clear': return initial();
    case 'remove': {
      const index = draft.entries.findIndex(entry => entry.id === action.id);
      if (index < 0) throw Error('条目不存在');
      draft.entries.splice(index, 1);
      return draft;
    }
    case 'add': {
      const name = String(action.name ?? '').trim();
      const tag = String(action.tag ?? '').trim() || '未分类';
      const quantity = Number(action.quantity);
      if (name.length === 0) throw Error('请填写名称');
      if (name.length > 32) throw Error('名称最多32个字符');
      if (!(Number.isInteger(quantity) && quantity >= 1 && quantity <= 99)) throw Error('数量须为1至99的整数');
      for (const entry of draft.entries) {
        if (entry.tag === tag && fold(entry.name) === fold(name)) throw Error('该分类中已有同名条目');
      }
      const id = draft.next;
      draft.next += 1;
      draft.entries = [...draft.entries, {id, name, tag, quantity}];
      return draft;
    }
    default: throw Error('未知操作');
  }
}
export function view(state, query = '', order = 'newest') {
  const needle = fold(String(query).trim());
  const entries = [];
  for (const entry of state.entries) {
    if (fold(entry.name + '\n' + entry.tag).includes(needle)) entries.push(entry);
  }
  entries.sort(order === 'name'
    ? (left, right) => left.name.localeCompare(right.name, 'zh-CN') || left.id - right.id
    : (left, right) => right.id - left.id);
  let quantity = 0;
  for (const entry of entries) quantity += entry.quantity;
  return {entries, items: entries.length, quantity};
}
