import {restore, change, view} from './core.mjs';
const controls = Object.fromEntries(['add','name','tag','quantity','query','order','rows','empty','summary','error','clear'].map(id => [id, document.getElementById(id)]));
const storageKey = 'rf-owned-desk-v1';
let current = restore(localStorage.getItem(storageKey));
function draw() {
  const visible = view(current, controls.query.value, controls.order.value);
  const fragment = document.createDocumentFragment();
  for (const entry of visible.entries) {
    const row = document.createElement('tr');
    for (const text of [entry.name, entry.tag, entry.quantity]) {
      const td = document.createElement('td');
      td.textContent = text;
      row.appendChild(td);
    }
    const actionCell = document.createElement('td');
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'remove';
    remove.textContent = '删除';
    remove.onclick = () => commit({type: 'remove', id: entry.id});
    actionCell.appendChild(remove);
    row.appendChild(actionCell);
    fragment.appendChild(row);
  }
  controls.rows.replaceChildren(fragment);
  controls.empty.hidden = visible.items > 0;
  controls.empty.textContent = current.entries.length === 0 ? '还没有条目，先添加一个吧。' : '没有匹配的条目。';
  controls.summary.textContent = `${visible.items} 项 · 共 ${visible.quantity} 件`;
}
function commit(action) {
  try {
    const updated = change(current, action);
    localStorage.setItem(storageKey, JSON.stringify(updated));
    current = updated;
    controls.error.textContent = '';
    draw();
    return true;
  } catch (failure) {
    controls.error.textContent = failure.message;
    return false;
  }
}
controls.add.onsubmit = event => {
  event.preventDefault();
  const accepted = commit({type: 'add', name: controls.name.value, tag: controls.tag.value, quantity: controls.quantity.value});
  if (accepted) {
    controls.name.value = '';
    controls.name.focus();
  }
};
controls.query.oninput = draw;
controls.order.onchange = draw;
controls.clear.onclick = () => {
  if (window.confirm('确定清空全部条目吗？')) commit({type: 'clear'});
};
draw();
