@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python serve.py
) else (
  py -3 serve.py
)
if errorlevel 1 pause
endlocal
