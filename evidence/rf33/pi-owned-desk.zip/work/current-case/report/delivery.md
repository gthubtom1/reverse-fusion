# 标签收纳盒交付与原版对照

交付日期：2026-11-16。目标：把提供的小软件复刻为界面、功能一致且可本地使用的版本，并实际对比原版。成果目录：项目根的 `标签收纳盒/`，六个文件；另提供同内容ZIP。

## 使用

Windows安装Python3后，双击 `标签收纳盒/start.cmd`。也可在该目录运行 `python serve.py`，浏览器打开 `http://127.0.0.1:8765/`。保持命令窗口运行，按Ctrl+C停止。同一浏览器/来源保存数据，换浏览器、端口或清网站数据不会共享。备份恢复方法见交付README。没有Node、npm、账号或原件依赖。

## 已实现范围

名称/分类/数量添加、去空白与默认分类、同分类忽略英文大小写防重；名称与数量边界提示；搜索名称或分类；最近添加/中文名称排序；筛选结果统计；删除单项；清空确认/取消；刷新恢复；损坏数据回退；保存失败不提交；纯文本渲染、成功添加焦点和输入保留。颜色、尺寸、布局与原版保持一致，包括原版手机窄屏的输入框溢出，没有擅自重新设计。

## 真实验证结果

| 检查 | 结果 | 原始记录 |
|---|---|---|
| 官方Spec工作流 | constitution/specify/clarify/plan/tasks/analyze/implement/converge实际执行，脚本输出与生成入口保留 | notes/spec-analysis.md、*-prerequisites.json、specs/001-recreate-desk/ |
| 原生Craft | 最终批次冻结T002..T006/T009，真实写入6文件、4条冻结检查、summary/cleanup和observer finish | final-native-*.json、native-final-lease.events.jsonl、session-final.json |
| 核心原版对照 | 108项通过，包括非法数量、名称长度、重复/跨分类、restore拒绝分支、排序、删除错误和输入不变性 | comparison/core-result.json、final-native-check-2.json |
| 桌面/手机对照 | 1100与390宽度各19状态，合计38状态；文本、行、错误、焦点、保存数据完全一致，页面错误为0 | comparison/package-result.json、original/与package/observation.json |
| 视觉对照 | 同Chrome157/zh-CN的38张截图SHA一致，无像素容差和字段排除；已人工查看桌面空态和手机填充态 | comparison/package/*.png |
| 错误变体 | 真实把显示总数加1后，原比较器返回exit1/fail，状态与截图差异被检出 | comparison/mutant-result.json |
| 最终目录启动 | 9项通过：固定端口启动、重复启动exit1、真实按钮/回车、刷新恢复、搜索、删除、清空、只请求包内资源；退出后端口关闭 | comparison/launch-result-fixed.json |
| 进程清理/预算 | 最后启动验证1156.402ms，job峰值475983872字节（约454MiB，含Chrome）；退出0，无截断，Windows Job关闭其子进程 | comparison/launch-process-fixed.json |
| 原件/交付身份 | 原件摘要不变；最终六文件对应原生cleanup摘要；最后仅serve.py变更，三份UI/业务源码与38状态对照完全同字节 | package-final-identity.json、package-identity.json |
| REA有限业务ledger | 真实官方CLI返回ready；6个原版业务义务verified，required_open=0 | desk-finite-ledger.json |

这里的性能数值只对应实际材料的一次运行，不是普遍性能承诺。测试由当前宿主编排、独立harness执行，不声称另一个模型/验证会话已独立审查。最终包的HTTP启动由自己的serve.py执行，浏览器请求范围限制在包内；这不构成文件系统/VM隔离证明。

## 保留的失败和修正

1. Windows PowerShell5.1默认编码导致case-init读中文case pointer失败；使用现有pwsh7恢复同一pointer后成功，未修改共享工具。
2. 首次调用把 `--tasks` 重复传入，CLI仅保留最后T006。没有将它当成全批任务证据；新native-complete批次一次传完整任务列表并重新写入/检查/退出。最终native-final再绑定完整任务与T009。
3. 启动器初版直接使用Python HTTPServer，Windows默认SO_REUSEADDR让第二实例重复绑定；实测等待45秒超时，Windows Job清理，原失败记录comparison/launch-process.json保留。查阅CPython issue85307和Microsoft Winsock说明后，改为Windows独占绑定。官方converge追加T009，新冻结批次通过真实Craft重建，最终端口冲突测试通过。旧启动器目录保存在comparison/package-before-launch-fix。

## 资格边界

原版完整REA静态分析保留454个语义unknown。最终两侧静态图+原业务义务的完整ledger为unknown：21 required /6 verified /15 required_open，包括14条生成图义务和1条原设计包装义务。没有删除它们。有限ledger只声明六项已实际对照的原版业务行为，启动包装是用户“能直接使用”的设计交付，另用真实启动/失败测试验收，不捏造原版不存在的包装观察。

集成proof由真实比较程序结果计算，使用仓库明确许可的REA6.9序列化适配器；官方CLI认证输入并计算ledger。它不是Windows原生PTY/process proof或全局程序等价证明。未提供真正VM/容器挂载隔离证明；其他浏览器/版本/locale、无限数据、并发跨页写入也未资格化。以上边界不改变本次约定的全部页面功能交付。

## 调用关系

```mermaid
flowchart LR
  A[浏览器输入] --> B[独立状态层 core.mjs]
  B --> C[page.mjs 先保存 localStorage]
  C --> D[提交内存并渲染]
  C --> E[保存失败显示原消息]
  F[serve.py 本机固定来源] --> A
```

## 恢复与回滚

规格和任务：`specs/001-recreate-desk/`；最终原生批次：`work/current-case/native-final-lease.json`和`session-final.json`；业务证明：desk-finite-proof.json/desk-finite-ledger.json；摘要：package-final-identity.json。最终源码在native-final/app与交付目录同字节。

全部应用任务完成。下一次用户提出差异或新需求时恢复同一case，对照原证据追加任务；不要重启旧租约或直接改已检查候选。回滚时先停止窗口并备份浏览器存储，用保留的目录/ZIP恢复源码；旧启动包装有已知重复端口问题，仅供失败复现。

## Evidence索引
E-001/E-002/E-003/E-004对应原始分析、浏览器观察、冻结承诺和初始ledger；E-005为真实有限proof，E-006为官方有限ledger，E-007为最终交付摘要，E-008为修复后实际启动验证。完整记录见evidence/INDEX.md。

