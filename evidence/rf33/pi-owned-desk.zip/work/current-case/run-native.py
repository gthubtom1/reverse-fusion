import subprocess,json,os,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
case='work/current-case'
python='D:/Project/reverse/.venv/Scripts/python.exe'
node='D:/Project/reverse/vendor/node/node-v24.22.1-win-x64/node.exe'
lease=f'{case}/native-final-lease.json'
commands=[f'"{node}" --check core.mjs',f'"{node}" --check page.mjs',f'"{node}" "{root.as_posix()}/{case}/core-diff.mjs" "{root.as_posix()}/reference/core.mjs" core.mjs',f'"{python}" -c "import ast; ast.parse(open(\'serve.py\', encoding=\'utf-8\').read())"']
base=[python,'-m','reverse_fusion']
def run(args,log):
 r=subprocess.run(base+args,cwd=root,env={**os.environ,'SPECIFY_INIT_DIR':str(root)},capture_output=True,timeout=100)
 (root/f'{case}/final-{log}.json').write_bytes(r.stdout)
 (root/f'{case}/final-{log}.stderr').write_bytes(r.stderr)
 text=r.stdout.decode('utf8',errors='replace')
 if r.returncode: print(text,r.stderr.decode('utf8',errors='replace'));raise SystemExit(r.returncode)
 print(text[:1800])
 return json.loads(text)
phase=sys.argv[1]
if phase=='prepare':
 args=['native-craft','prepare','--project-root',str(root),'--lease',lease,'--workspace',f'{case}/native-final','--receipt',f'{case}/session-final.json','--case-root',case,'--handoff-manifest',f'{case}/notes/handoff-launch.json','--review-file',f'{case}/notes/launch-correction.md','--task-file','specs/001-recreate-desk/tasks.md','--command-timeout','60']
 args+=['--tasks','T002','T003','T004','T005','T006','T009']
 for p in ['core.mjs','page.mjs','index.html','serve.py','start.cmd','README.md']:args+=['--allowed-output','app/'+p]
 for p in [f'{case}/notes/validation-commitment.json',f'{case}/core-diff.mjs',f'{case}/compare-ui.mjs',f'{case}/verify-ui.cjs','reference/index.html','reference/core.mjs','reference/page.mjs','specs/001-recreate-desk/research.md','specs/001-recreate-desk/data-model.md','specs/001-recreate-desk/contracts/ui.md']:args+=['--research-file',p]
 for c in commands:args+=['--check-command',c]
 run(args,'native-prepare')
elif phase=='build':
 for p in ['core','page','index','serve','start','readme']:run(['native-craft','build','--project-root',str(root),'--lease',lease,'--params-file',f'{case}/requests/{p}.json'],'native-write-'+p)
elif phase=='check':
 for i,c in enumerate(commands):
  p=root/f'{case}/requests/check-{i}.json';p.write_text(json.dumps({'command':c,'timeout_secs':60})+'\n',encoding='utf8')
  run(['native-craft','check','--project-root',str(root),'--lease',lease,'--params-file',p.relative_to(root).as_posix()],f'native-check-{i}')
elif phase=='finish':
 for op in ['return_summary','cleanup']:run(['native-craft',op,'--project-root',str(root),'--lease',lease],'native-'+op)
 for op in ['check','refine','finish']:run(['session',op,'--project-root',str(root),'--receipt',f'{case}/session-final.json'],'observer-'+op)
else:raise SystemExit('unknown phase')
