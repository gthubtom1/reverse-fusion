import {createRequire} from 'node:module';
import fs from 'node:fs';
const require = createRequire(import.meta.url);
const {chromium} = require('C:/Users/toti/.pi/agent/npm/node_modules/playwright');
const browser = await chromium.launch({channel:'chrome',headless:true});
const context = await browser.newContext({viewport:{width:1280,height:900},deviceScaleFactor:1});
const page = await context.newPage();
const observations=[];
const snap=async name=>observations.push({name,rows:await page.locator('#rows').innerText(),summary:await page.locator('#summary').innerText(),error:await page.locator('#error').innerText(),empty:await page.locator('#empty').isVisible(),focus:await page.evaluate(()=>document.activeElement.id),stored:await page.evaluate(()=>localStorage.getItem('rf-owned-desk-v1'))});
await page.goto('http://127.0.0.1:8765');
await page.screenshot({path:'work/current-case/original-desktop.png',fullPage:true});
await snap('empty');
for (const [name,tag,quantity] of [[' USB 线 ',' 电子 ','2'],['笔记本','办公','4'],['USB 线','备用','1']]) {
 await page.locator('#name').fill(name);await page.locator('#tag').fill(tag);await page.locator('#quantity').fill(quantity);await page.getByRole('button',{name:'添加条目'}).click();
}
await snap('added');
await page.reload();await snap('reloaded');
await page.locator('#query').fill(' USB ');await snap('searched');
await page.locator('.remove').first().click();await snap('removed');
page.once('dialog', d=>d.dismiss());await page.locator('#clear').click();await snap('clear-cancel');
page.once('dialog', d=>d.accept());await page.locator('#clear').click();await snap('clear-confirm');
await page.setViewportSize({width:390,height:844});await page.screenshot({path:'work/current-case/original-mobile.png',fullPage:true});
fs.writeFileSync('work/current-case/browser-original.json',JSON.stringify({browser:browser.version(),observations},null,2));
await browser.close();
console.log(JSON.stringify({observations:observations.length,browser:'chrome',status:'observed'}));
