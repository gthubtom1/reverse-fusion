from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
import threading, sys
root = Path(sys.argv[1]).resolve()
server = ThreadingHTTPServer(('127.0.0.1', int(sys.argv[2])), partial(SimpleHTTPRequestHandler, directory=str(root)))
threading.Timer(3600, server.shutdown).start()
print('READY', server.server_address, str(root), flush=True)
try:
    server.serve_forever()
finally:
    server.server_close()
