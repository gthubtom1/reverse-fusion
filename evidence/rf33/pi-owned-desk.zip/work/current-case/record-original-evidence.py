import subprocess
from pathlib import Path
project=Path(__file__).resolve().parents[2]
case=project/'work/current-case'
entries=[('E-001','Original official JavaScript application Evidence','rea-original.json','Official REA analyze-javascript-application; raw bundle retained, static unknowns remain'),('E-002','Original desktop/mobile runtime observations','original-ui/observation.json','node work/current-case/verify-ui.cjs reference work/current-case/original-ui (new output path on replay)'),('E-003','Original identity and frozen comparison plan','notes/validation-commitment.json','python work/current-case/prepare-validation.py; inputs fixed before candidate'),('E-004','Official initial obligation ledger','ledger-initial.json','official rea build-reconstruction-obligation-ledger ledger-initial-input.json; open obligations are not acceptance')]
for eid,title,artifact,repro in entries:
    run=subprocess.run(['pwsh','-NoProfile','-File','D:/Project/reverse/skills/scripts/append-evidence.ps1','-CaseRoot',str(case),'-Id',eid,'-Title',title,'-ReproCommand',repro,'-ArtifactPath',artifact,'-Status','observed','-Notes','Same retained case. Source qualifications remain limited; do not infer global equivalence.'],cwd=project,capture_output=True,timeout=15)
    print(run.stdout.decode('utf8',errors='replace'))
    if run.returncode: raise RuntimeError(run.stderr.decode('utf8',errors='replace'))
