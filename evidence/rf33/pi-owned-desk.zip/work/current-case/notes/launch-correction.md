# Windows launch correction review

Actual delivered-server test timed out before opening Chrome. Its second Python HTTPServer could bind the same port rather than rejecting a duplicate instance. Windows Job closed all owned descendants at45s; comparison/launch-process.json remains the failed result.

Research: Python cpython issue85307 (opened2020, discussion through2023) describes HTTPServer default SO_REUSEADDR permitting duplicate binding on Windows. Microsoft Winsock documentation specifies SO_EXCLUSIVEADDRUSE must be set before bind, and SO_REUSEADDR has different Windows semantics. Sources:
- https://github.com/python/cpython/issues/85307
- https://learn.microsoft.com/en-us/windows/win32/winsock/using-so-reuseaddr-and-so-exclusiveaddruse

Correction: a small ThreadingHTTPServer subclass uses no address reuse on Windows and sets SO_EXCLUSIVEADDRUSE before super.server_bind; Unix keeps existing reuse behavior. Original JS/UI remains unchanged. Duplicate instance must exit1 without disturbing first server. Finite test remains same expectation; no timeout loosened. Rerun startup, real button/keyboard, persistence, search/delete/clear and socket closure under bounded owned job.

Official converge found one partial FR-007/SC-004 launch obligation, appended T009; did not change intent or application code. No other spec gaps identified. New reviewed batch uses native-final/app and receipt session-final.json; retains earlier successful/failed batches. This is same authorized whole-application goal, with no new service/model/provider.
